// ============================================================================
// network.js — 멀티플레이어 어댑터
// BoardMate Arcade (https://board-mate.github.io/arena/index.html#/multi)
// 연동을 위한 준비 구조. 현재: LocalHotseatAdapter 동작.
// ============================================================================

class LocalHotseatAdapter {
  publish() {}
  onRemoteUpdate() {}
  isConnected() { return false; }
}

class ArcadeAdapter {
  // TODO: BoardMate Arcade API 연동
  // board-mate.github.io/arena의 API를 파악하면 여기를 채웁니다.
  // 예상 패턴: postMessage / BroadcastChannel / WebSocket
  constructor() {
    this._callbacks = [];
    this._tryConnect();
  }
  _tryConnect() {
    // iframe 환경 감지
    if (window.parent !== window) {
      window.addEventListener('message', (e) => {
        if (e.data?.type === 'game_state') {
          this._callbacks.forEach(cb => cb(e.data.state));
        }
      });
    }
  }
  publish(state) {
    // 상태를 직렬화 가능한 형태로 변환 후 전송
    try {
      const serialized = JSON.stringify(state, (k,v) => {
        if (v instanceof Map) return { __map: [...v.entries()] };
        return v;
      });
      if (window.parent !== window) {
        window.parent.postMessage({ type:'game_state', state:serialized }, '*');
      }
    } catch(e) { /* 직렬화 실패 무시 */ }
  }
  onRemoteUpdate(cb) { this._callbacks.push(cb); }
  isConnected() { return window.parent !== window; }
}

export function createNetworkAdapter() {
  // iframe 안에 있으면 Arcade, 아니면 local
  return window.parent !== window
    ? new ArcadeAdapter()
    : new LocalHotseatAdapter();
}
